def change_language(request, lang):

    return 1

