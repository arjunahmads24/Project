
from django.http import JsonResponse

from article_website.functions import (
    int_or,

    get_or_none,
    get_and_delete,
    get_and_delete_or_create,
)
from .models import (
    Article, 
    ArticleLike,
    ArticleDislike,
    Comment,
    CommentLike,
    CommentDislike,
    CommentReport
)

from .functions import (
    get_articles as _get_articles,
    get_related_articles as _get_related_articles
)

def JsonResponseStatus(status: int):
    return JsonResponse({"status": status})

def get_articles(request):

    category = request.GET.get("category")
    keyword = request.GET.get("keyword")
    section = int_or(request.GET.get("section"))


    if not category:
        category = None
    if not keyword:
        keyword = None

    if not section:
        section = 1

    start_idx = 12*(section - 1)
    end_idx = 12*(section)

    
    articles = _get_articles(start_idx=start_idx, end_idx=end_idx, category=category, keyword=keyword)
    article_json_list = []

    if articles is None:
        return JsonResponseStatus(404)

    for i in range(len(articles)):
        article = articles[i]
        article_json = {}
        article_json["category"] = article.category.name
        article_json["title"] = article.title
        article_json["sinposis"] = article.sinopsis
        article_json["body"] = article.body
        article_json["like_count"] = article.articlelike_set.count()
        article_json["comment_count"] = article.comment_set.count()
        article_json_list.append(article_json)

    return JsonResponse(article_json_list, safe=False)


def get_related_articles(request, slug):
    ...

def get_comments(request):
    ...
    return JsonResponseStatus(200)

def edit_comment(request, article_slug, comment_id):

    user = request.user
    data = request.POST

    comment = get_or_none(Comment, id=comment_id)
    if comment == None:
        return JsonResponseStatus(404)
    elif comment.user != user:
        return JsonResponseStatus(400)
    
    # Check the new body
    new_body = data["new_body"]
    if not new_body:
        return JsonResponseStatus(404)
    
    # Set the new body
    comment.body = new_body
    comment.save()

    return JsonResponseStatus(200)


def delete_comment(request, article_slug, comment_id):

    user = request.user
    data = request.POST

    comment = get_or_none(Comment, id=comment_id)
    if comment == None:
        return JsonResponseStatus(404)
    elif comment.user != user:
        return JsonResponseStatus(400)
   
    
    # Delete the comment
    comment.delete()

    return JsonResponseStatus(200)


def like_comment(request, article_slug, comment_id):

    user = request.user
    data = request.POST

    comment = get_or_none(Comment, id=comment_id)
    if comment == None:
        return JsonResponseStatus(404)
    
    if get_and_delete_or_create(CommentLike, user=user, comment=comment) != 1:
        get_and_delete(CommentDislike, user=user, comment=comment)

    return JsonResponseStatus(200)


def dislike_comment(request, article_slug, comment_id):

    user = request.user
    data = request.POST

    comment = get_or_none(Comment, id=comment_id)
    if comment == None:
        return JsonResponseStatus(404)
    
    if get_and_delete_or_create(CommentDislike, user=user, comment=comment) != 1:
        get_and_delete(CommentLike, user=user, comment=comment)

    return JsonResponseStatus(200)


def report_comment(request, article_slug, comment_id):

    user = request.user
    data = request.POST

    comment = get_or_none(Comment, id=comment_id)
    if comment == None:
        return JsonResponseStatus(404)
    
    report_message = data["report_message"]
    if get_and_delete_or_create(CommentReport, user=user, comment=comment, report_message=report_message) != 1:
        pass

    return JsonResponseStatus(200)