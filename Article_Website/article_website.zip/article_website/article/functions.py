from django.db.models import Q
from django.http import HttpResponse, JsonResponse

from .models import (
    Category,
    Article, 
    ArticleLike, 
    ArticleDislike, 
    Comment, 
    CommentLike, 
    CommentDislike, 
    CommentReport
)

from account.models import User

from article_website.functions import (
    create_obj, 
    get_or_none, 
    get_list_or_none, 
    get_and_delete, 
    get_and_delete_or_create
)


# Article
# def get_top_articles():
# def get_newest_articles():


def get_articles(start_idx=None, end_idx=None, category=None, keyword=None):
    articles = get_list_or_none(Article, start_idx, end_idx)
    if category is not None:
        category = get_or_none(Category, name=category)
        articles = articles.filter(category=category)
    if keyword is not None:
        articles = articles.filter(Q(title__icontains=keyword))
    return articles

def get_related_articles(article: Article = None):
    article_tags = article.taginarticle_set.all()
    # Process with tag
    ...
    related_articles = get_list_or_none(Article, category=article.category) # Add exclude here
    return related_articles

def increase_article_view_count(article: Article):
    article.view_count += 1
    article.save()

def like_article(user: User, article: Article):
    kwargs = {"user": user, "article": article}
    if user.is_authenticated:
        if get_and_delete(ArticleLike, kwargs) == 0:
            create_obj(ArticleLike, kwargs)
            get_and_delete(ArticleDislike, kwargs) # Deleting the article-dislike by the same user if it exists

def dislike_article(user: User, article: Article):
    kwargs = {"user": user, "article": article}
    if user.is_authenticated:
        if get_and_delete(ArticleDislike, kwargs) == 0:
            create_obj(ArticleDislike, kwargs)
            get_and_delete(ArticleLike, kwargs) # Deleting the article-like by the same user if it exists
            

# Comment

# AJAX Request

def get_comments(article: Article):
    return get_list_or_none(Comment, article=article, comment=None)

def get_comment_replies(comment: Comment):
    return get_list_or_none(Comment, comment=comment)

def add_comment(user: User, article: Article, body: str, comment: Comment = None):
    create_obj(Comment, user=user, article=article, body=body, comment=comment)

def edit_comment(comment: Comment, body: str, save=True):
    comment.body = body
    if save == True:
        comment.save()

def delete_comment(comment: Comment):
    get_and_delete(comment)

def like_comment(user: User, comment: Comment):
    kwargs = {"user": user, "comment": comment}
    if user.is_authenticated:
        if get_and_delete(CommentLike, kwargs) == 0:
            create_obj(CommentLike, kwargs)
            get_and_delete(CommentDislike, kwargs) # Deleting the comment-dislike by the same user if it exists

def dislike_comment(user: User, comment: Comment):
    kwargs = {"user": user, "comment": comment}
    if user.is_authenticated:
        if get_and_delete(CommentDislike, kwargs) == 0:
            create_obj(CommentDislike, kwargs)
            get_and_delete(CommentLike, kwargs) # Deleting the comment-like by the same user if it exists

def report_comment(user: User, comment: Comment, report_message: str):
    kwargs = {"user": user, "comment": comment, "report_message": report_message}
    if user.is_authenticated:
        if get_or_none(CommentReport, user=user, comment=comment) == None:
            create_obj(CommentReport, kwargs)
            return 1
        else:
            return JsonResponse({
                "status": "error", 
                "message_code": "443",
                "message": "You have already report this comment"
            })