from django.contrib import admin
from django.urls import path, include
from . import views, ajax_handler

urlpatterns = [
    # For HTTP Request
    path("", views.home, name="home"),
    path("discovery", views.discovery, name="discovery"),
    path("article/<str:slug>/", views.article_detail, name="article_detail"),
    path("<str:category>/", views.category, name="category"),
    path("<str:category>/<str:sub_category>/", views.category, name="category"),

    # For AJAX Request
    path("article/get_articles", ajax_handler.get_articles),
    path("article/<str:slug>/get_related_articles", ajax_handler.get_related_articles),
    
    path("article/<str:slug>/comment/get_comments", ajax_handler.get_comments),
    path("article/<str:slug>/comment/<int:comment_id>/edit", ajax_handler.edit_comment),
    path("article/<str:slug>/comment/<int:comment_id>/delete", ajax_handler.delete_comment),
    path("article/<str:slug>/comment/<int:comment_id>/like", ajax_handler.like_comment),
    path("article/<str:slug>/comment/<int:comment_id>/dislike", ajax_handler.dislike_comment),
    path("article/<str:slug>/comment/<int:comment_id>/report", ajax_handler.report_comment),
]


