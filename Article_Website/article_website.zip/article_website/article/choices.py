from article_website.definitions import color

color_choices = {
    (color.DARKBLUE, "Dark Blue"),
    (color.BLUE, "Blue"),
    (color.ORANGE, "Orange"),
    (color.YELLOW, "Yellow"),
}