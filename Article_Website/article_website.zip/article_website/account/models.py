from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

from article_website.definitions import gender, language, theme

from .choices import *



def user_avatar_path(instance, file_name):
    ext = file_name.split(".")[-1]
    dir = "img/user/avatar/"
    full_path = dir + f"{dir}{instance.id}.{ext}"
    return full_path

class UserManager(BaseUserManager):
    def create_user(self, username, email, date_of_birth, password=None, **kwargs):
        user = self.model(username=username, email=email, date_of_birth=date_of_birth, **kwargs)
        user.set_password(password)
        user.save(using=self._db)
        return user
    def create_superuser(self, username, email, date_of_birth, password=None, **kwargs):
        user = self.create_user(username, email, date_of_birth, password, **kwargs)
        user.is_active = True
        user.is_admin = True
        user.is_staff = True
        user.save(using=self._db)
        return user

class User(AbstractBaseUser):

    objects = UserManager()
    def __str__(self):
        return self.username

    id = models.BigAutoField(primary_key=True)

    username = models.CharField(max_length=64, unique=True)
    gender = models.PositiveSmallIntegerField(choices=gender_choices, default=gender.PREFER_NOT_SAY)
    email = models.EmailField(
        max_length=255,
    )
    phone_number = models.CharField(
        max_length=17,
        blank=True,
        null=True,
    )
    avatar = models.ImageField(blank=True, null=True, upload_to=user_avatar_path)

    date_of_birth = models.DateField()
    datetime_joined = models.DateTimeField(auto_now_add=True)

    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)    
    is_staff = models.BooleanField(default=False) # AKA: is_writer

    language = models.PositiveSmallIntegerField(choices=language_choices, default=language.IDN)
    theme = models.PositiveSmallIntegerField(choices=theme_choices, default=theme.LIGHT)
    
    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = ["email", "date_of_birth"]

    def has_perm(self, perm, obj=None):
        return True
    def has_module_perms(self, app_label):
        return True
    
    def set_language(self, language):
        self.language = language
        return True

    def set_theme(self, theme):
        self.theme = theme
        return True
    