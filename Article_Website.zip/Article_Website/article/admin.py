from django.contrib import admin
from .models import Article, Category


class ArticleAdmin(admin.ModelAdmin):

    fields = ["category", "author", "title", "sinopsis", "body"]

    def has_change_permission(self, request, obj: Article = None):
        if obj is not None and obj.author != request.user:
            return False
        return True
    def has_delete_permission(self, request, obj: Article = None):
        if obj is not None and obj.author != request.user:
            return False
        return True

admin.site.register(Category)
admin.site.register(Article, ArticleAdmin)