from django.shortcuts import render, redirect

from django.http import JsonResponse

from article_website.functions import get_or_none, get_list_or_none, render_404
from .models import Category, Article


def home(request):

    user = request.user
    theme = "light"

    if user.is_authenticated:
        theme = user.get_theme_display()

    # Direct request
    return render(request, "home.html", {
        "user": user,
        "theme": theme,
    })
    # AJAX request

def category(request, category: str, sub_category: str = None, page: int = 1):

    # Direct request
    if sub_category != None:
        category = sub_category

    category = get_or_none(Category, name=category)
    if category == None:
        return render_404(request)

    # Fetch the articles
    n_articles = 12 # The number of articles in one page
    start = n_articles * (page - 1)
    end = n_articles * page

    articles = get_list_or_none(Article, start=start, end=end)

    return render(request, "category.html", {
        "articles": articles,
    })

    # AJAX request
    return JsonResponse()
    
def discovery(request):
    return JsonResponse()

def article_detail(request, slug: str):
    """
    Task:
    - Consider to use the id instead of slug to increase the indexing performance
    """
    article = get_or_none(Article, slug=slug)
    if article is None:
        return render_404(request)
    
    return render(request, "article_detail.html", {
        "article": article
    })

    # AJAX request

