
class Comment {
    dom;
    id;
    body;
    author_avatar_url;
    date_published;
    
    edit(new_body) {
        url = window.location.href + "/comment/" + this.id + "/edit";
        data = {"new_body": new_body}
        $.post(url, data, function(response) {
            reload_comment();
        });
    }
    delete() {
        url = window.location.href + "/comment/" + this.id + "/delete";
        $.post(url, function(response) {
            
        });
    }
    like() {
        let like_btn = this.dom.querySelector(".like-btn");
        switch_icon(like_btn);
        url = window.location.href + "/comment/" + this.id + "/like";
        $.post(url, function(response) {
            // if error then undo the switch icon
            if (response.status != 200) {
                switch_icon(like_btn);
            }
        });
    }
    dislike() {
        let dislike_btn = this.dom.querySelector(".dislike-btn");
        switch_icon(dislike_btn);
        url = window.location.href + "/comment/" + this.id + "/dislike";
        $.post(url, function(response) {
            // if error then undo the switch icon
            if (response.status != 200) {
                switch_icon(dislike_btn);
            }
        });
    }
}