function switch_icon(el) {
    if (el.classList.contains("active")) {
        el.classList.remove("active");
    } else {
        el.classList.add("active");
    }
}

class Article {
    dom;
    id;
    title;
    sinposis;
    body;
    view_count;
    like() {
        let like_btn = this.dom.querySelector(".like-btn");
        switch_icon(like_btn);
        url = window.location.href + "/like";
        $.post(url, function(response) {
            // if error then undo the switch icon
            if (response.status != 200) {
                switch_icon(like_btn);
            }
        });
    }
    dislike() {
        let dislike_btn = this.dom.querySelector(".dislike-btn");
        switch_icon(dislike_btn);
        url = window.location.href + "/dislike";
        $.post(url, function(response) {
            // if error then undo the switch icon
            if (response.status != 200) {
                switch_icon(dislike_btn);
            }
        });
    }
}
