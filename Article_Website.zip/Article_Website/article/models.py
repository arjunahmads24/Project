from django.db import models

from article_website import settings
from article_website.functions import calc_minute_read, slugify

from .choices import *

from account.models import User


""""

Questions:
- Is django automatically create id for a table?
- How to login with google in django website?

"""


class Category(models.Model):
    id = models.BigAutoField(primary_key=True)

    category = models.ForeignKey(to="self", related_name="sub_category", blank=True, null=True, on_delete=models.SET_NULL)

    name = models.CharField(max_length=64)
    color = models.PositiveSmallIntegerField(choices=color_choices)

    
class Article(models.Model):
    # Primary key field
    id = models.BigAutoField(primary_key=True)
    
    # Foregin key field
    category = models.ForeignKey(to=Category, null=True, on_delete=models.SET_NULL)
    author = models.ForeignKey(to=settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

    # Char and text field
    slug = models.CharField(max_length=255, blank=True, null=True)
    title = models.CharField(max_length=255, unique=True)
    sinopsis = models.TextField()
    body = models.TextField()
    minute_read = models.PositiveSmallIntegerField(blank=True, null=True)

    # Integer field
    view_count = models.PositiveIntegerField(default=0)

    # Date field
    datetime_published = models.DateTimeField(auto_now_add=True)
    datetime_last_modified = models.DateTimeField(auto_now=True)

    def get_like_count(self):
        return self.articlelike_set.count()
    def get_dislike_count(self):
        return self.articledislike_set.count()
    def get_comment_count(self):
        return self.comment_set.count()

    def save(self, *args, **kwargs):
        self.slug = slugify(self.title)
        self.minute_read = calc_minute_read(self.body)
        super().save(*args, **kwargs)


class Tag(models.Model):
    id = models.BigAutoField(primary_key=True)

    name = models.CharField(max_length=64)
    color = models.PositiveSmallIntegerField(choices=color_choices)


class TagInArticle(models.Model):
    id = models.BigAutoField(primary_key=True)

    tag = models.ForeignKey(to=Tag, on_delete=models.CASCADE)
    article = models.ForeignKey(to=Article, on_delete=models.CASCADE)


class ArticleLike(models.Model):
    article = models.ForeignKey(to=Article, on_delete=models.CASCADE)
    user = models.ForeignKey(to=settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)

    datetime_added = models.DateTimeField(auto_now_add=True)


class ArticleDislike(models.Model):
    article = models.ForeignKey(to=Article, on_delete=models.CASCADE)
    user = models.ForeignKey(to=settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)

    datetime_added = models.DateTimeField(auto_now_add=True)


# Comment

class Comment(models.Model):
    id = models.BigAutoField(primary_key=True)

    # Foreign key field
    article = models.ForeignKey(to=Article, on_delete=models.CASCADE)
    user = models.ForeignKey(to=User, null=True, on_delete=models.SET_NULL)
    comment = models.ForeignKey("self", related_name="comment_reply", null=True, on_delete=models.CASCADE)

    body = models.CharField(max_length=255)

    datetime_added = models.DateTimeField(auto_now_add=True)
    datetime_last_modified = models.DateTimeField(auto_now=True)

    def get_like_count(self):
        return self.commentlike_set.count()
    def get_dislike_count(self):
        return self.commentdislike_set.count()
    def get_report_count(self):
        return self.commentreport_set.count()


class CommentLike(models.Model):
    comment = models.ForeignKey(to=Comment, on_delete=models.CASCADE)
    user = models.ForeignKey(to=User, null=True, on_delete=models.SET_NULL)

    datetime_added = models.DateTimeField(auto_now_add=True)


class CommentDislike(models.Model):
    comment = models.ForeignKey(to=Comment, on_delete=models.CASCADE)
    user = models.ForeignKey(to=User, null=True, on_delete=models.SET_NULL)

    datetime_added = models.DateTimeField(auto_now_add=True)


class CommentReport(models.Model):
    comment = models.ForeignKey(to=Comment, on_delete=models.CASCADE)
    user = models.ForeignKey(to=User, null=True, on_delete=models.SET_NULL)
    
    report_message = models.CharField(max_length=255)

    datetime_added = models.DateTimeField(auto_now_add=True)