
from django.http import JsonResponse

from article_website.functions import (
    int_or,

    create_obj,
    get_or_none,
    get_and_delete,
    get_and_delete_or_create,
)
from .models import (
    Category,
    Article, 
    ArticleLike,
    ArticleDislike,
    Comment,
    CommentLike,
    CommentDislike,
    CommentReport
)

from .functions import (
    get_articles as _get_articles,
    get_related_articles as _get_related_articles,
    get_comments as _get_comments,
)

def JsonResponseStatus(status: int):
    return JsonResponse({"status": status})

def get_articles(request):

    category = get_or_none(Category, name=request.GET.get("category"))
    keyword = request.GET.get("keyword")
    session = int_or(request.GET.get("session"))

    if category is None:
        """
        if the category name retrieved from the client is not exist in the database (ex: "" or "jfhdf""), the category variable above will be None and all the articles is still will be loaded.
        """
        pass
    if not keyword:
        keyword = None
    if not session:
        session = 1

    start_idx = 12*(session - 1)
    end_idx = 12*(session)

    articles = _get_articles(start_idx=start_idx, end_idx=end_idx, category=category, keyword=keyword)
    article_json_list = []

    for i in range(len(articles)):
        article = articles[i]
        article_json = {}
        article_json["category"] = article.category.name
        article_json["title"] = article.title
        article_json["slug"] = article.slug
        article_json["sinopsis"] = article.sinopsis
        article_json["body"] = article.body
        article_json["like_count"] = article.articlelike_set.count()
        article_json["comment_count"] = article.comment_set.count()
        article_json_list.append(article_json)

    return JsonResponse(article_json_list, safe=False)


def get_related_articles(request, slug):
    ...



def post_comment(request, article_slug):
    user = request.user
    if not user.is_authenticated:
        return JsonResponseStatus(401) # Indicates that the user must log in first

    # Validate the body
    body = request.POST.get("body")
    if not body:
        return JsonResponseStatus(404)

    article = get_or_none(Article, slug=article_slug)
    if article == None:
        return JsonResponseStatus(404)

    create_obj(Comment, user=user, article=article, body=body)

    return JsonResponseStatus(200)


def get_comments(request, article_slug):
    user = request.user

    article = get_or_none(Article, slug=article_slug)
    if article == None:
        return JsonResponseStatus(404)
    comments = get_list_or_none(Comment, article=article)

    comment_json_list = []

    for i in range(len(comments)):
        comment = comments[i]
        comment_json = {}
        comment_json["author_name"] = comment.author.name
        comment_json["body"] = comment.body
        comment_json["datetime_added"] = comment.datetime_added
        comment_json["like_count"] = comment.commentlike_set.count()
        comment_json["commentreply_count"] = comment.commentreply_set.count()
        if comment.user == user:
            comment_json["is_mine"] = True
        comment_json_list.append(comment_json)

    return JsonResponse(comment_json_list, safe=False)



def edit_comment(request, article_slug, comment_id):

    user = request.user
    data = request.POST

    comment = get_or_none(Comment, id=comment_id)
    if comment == None:
        return JsonResponseStatus(404)
    elif comment.user != user:
        return JsonResponseStatus(404)
    
    # Check the new body
    new_body = data["new_body"]
    if not new_body:
        return JsonResponseStatus(404)
    
    # Set the new body
    comment.body = new_body
    comment.save()

    return JsonResponseStatus(200)


def delete_comment(request, article_slug, comment_id):

    user = request.user
    data = request.POST

    comment = get_or_none(Comment, id=comment_id)
    if comment == None:
        return JsonResponseStatus(404)
    elif comment.user != user:
        return JsonResponseStatus(400)
   
    
    # Delete the comment
    comment.delete()

    return JsonResponseStatus(200)


def like_comment(request, article_slug, comment_id):

    user = request.user
    data = request.POST

    comment = get_or_none(Comment, id=comment_id)
    if comment == None:
        return JsonResponseStatus(404)
    
    if get_and_delete_or_create(CommentLike, user=user, comment=comment) != 1:
        get_and_delete(CommentDislike, user=user, comment=comment)

    return JsonResponseStatus(200)


def dislike_comment(request, article_slug, comment_id):

    user = request.user
    data = request.POST

    comment = get_or_none(Comment, id=comment_id)
    if comment == None:
        return JsonResponseStatus(404)
    
    if get_and_delete_or_create(CommentDislike, user=user, comment=comment) != 1:
        get_and_delete(CommentLike, user=user, comment=comment)

    return JsonResponseStatus(200)


def report_comment(request, article_slug, comment_id):

    user = request.user
    data = request.POST

    comment = get_or_none(Comment, id=comment_id)
    if comment == None:
        return JsonResponseStatus(404)
    
    report_message = data["report_message"]
    if get_and_delete_or_create(CommentReport, user=user, comment=comment, report_message=report_message) != 1:
        pass

    return JsonResponseStatus(200)