"""Definitions of class and its attributes that used in field's choices"""

class color:
    DARKBLUE = 1
    BLUE = 2
    ORANGE = 3
    YELLOW = 4

class gender:
    PREFER_NOT_SAY = 0
    MALE = 1
    FEMALE = 2
    
class language:
    IDN = 1
    USA = 2

class theme:
    LIGHT = 1
    DARK = 2