
from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist

from django.shortcuts import render


# Global
def int_or(n):
    try:
        return int(n)
    except:
        return 0

# Views

def render_404(request):
    return render(request, "error_404.html")


# Database

def create_obj(model, save=True, **kwargs):
    obj = model(**kwargs)
    if save == True:
        obj.save()
    return obj

def get_or_none(model, **kwargs):
    try:
        obj = model.objects.get(**kwargs)
        return obj
    except MultipleObjectsReturned:
        return None
    except ObjectDoesNotExist:
        return None
    except:
        return None

def get_list_or_none(model, start_idx: int = None, end_idx: int = None, **kwargs):
    try:
        objs = model.objects.filter(**kwargs)[start_idx:end_idx]
        return objs
    except:
        return None

def get_or_create(model, **kwargs):
    try:
        obj = model.objects.get(**kwargs)
        return obj
    except MultipleObjectsReturned:
        return None
    except ObjectDoesNotExist:
        return create_obj(model, kwargs=kwargs)
    except:
        return None
    
def get_and_delete(model, **kwargs):
    obj
    try:
        obj = model.objects.get(**kwargs)
        obj.delete()
        return 1
    except MultipleObjectsReturned:
        objs = model.objects.filter(**kwargs)
        objs.delete()
        return 1
    except:
        # When there is no object found
        return 0

def get_and_delete_or_create(model, **kwargs):
    if get_and_delete(model, **kwargs) == 0:
        obj = create_obj(model, kwargs=kwargs)
        return obj
    return 1


# Etc

def calc_minute_read(text: str):
    average_wpm = 238 # The average silent reading for non-fiction in words per minute
    words_count = len(text.split(" "))
    minute_read = words_count / average_wpm
    return minute_read

def slugify(text: str):
    return text.replace(" ", "-").lower()