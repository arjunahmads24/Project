
from django.http import HttpResponse
from django.shortcuts import render


def terms_of_use(request):
    return HttpResponse()

def privacy_policy(request):
    return HttpResponse()

def cookie_settings(request):
    return HttpResponse()

def about_us(request):
    return HttpResponse()

def advertisement(request):
    return HttpResponse()


# Error

def error_404(request):
    return render(request, "error_404.html")
