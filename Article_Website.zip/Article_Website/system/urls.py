from django.contrib import admin
from django.urls import path, include

from . import views


urlpatterns = [
    path("terms-of-use", views.terms_of_use, name="terms_of_use"),
    path("privacy-policy", views.privacy_policy, name="privacy_policy"),
    path("cookie-settings", views.cookie_settings, name="cookie_settings"),
    path("about-us", views.about_us, name="about_us"),
    path("advertisement", views.advertisement, name="advertisement"),
]