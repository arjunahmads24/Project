
# questions
# - How to login user with google


from .models import User


def create_user(**kwargs):
    try:
        User.model(kwargs)
    except:
        return False
    return user


def get_user_or_none(username=username, password=password)



def login(request, **kwargs):

    user = get_or_none(User, )

    if user:
        login(request)

def logout():
    return

def change_password():
    return

def change_username():
    return

def delete_account():
    return

def change_language():
    return