class Auth {
    signup(username, email, password, confirm_password) {
        // Validation goes here
        $.post("/signup", data=data, function(response) {
            // if success signup 
            //      then redirect to the next_url
            // else 
            //      show error message using tex-box messsage
        });
    }
    login(username=NaN, email=NaN) {
        $.post("/login", data=data, function(response) {
            // if success login:
            //      client:
            //          update the profile picture
            //      server:
            //          sign the request user
        });
    }
    logout() {
        $.post("/logout", function(response) {

        });
    }
}