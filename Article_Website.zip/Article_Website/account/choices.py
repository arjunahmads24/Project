from article_website.definitions import gender, language, theme


gender_choices = {
    (gender.PREFER_NOT_SAY, "Prefer not to say"),
    (gender.MALE, "Male"),
    (gender.FEMALE, "Female"),
}

language_choices = {
    (language.IDN, "Bahasa Indonesia"),
    (language.USA, "English USA"),
}

theme_choices = {
    (theme.LIGHT, "Light"),
    (theme.DARK, "Dark"),
}