from django.http import HttpResponse
from django.shortcuts import render

def signup(request):
    
    return render(request, "signup.html")

def login(request):
    
    return render(request, "login.html")

def forgot_password(request):
    ...

def logout(request):
    
    return render(request, "logout.html")


# Account

def my_profile(request):
    return HttpResponse()

def set_password(request):
    ...